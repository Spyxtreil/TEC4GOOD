# TaskFlow — Desktop Task Manager

A clean, modern Python desktop app for managing tasks with notifications
and optional Google Calendar sync.

---

## Quick Start

### 1. Install Python
Requires **Python 3.10+**.  Download from https://python.org.

### 2. Install dependencies
```bash
pip install -r requirements.txt
```

### 3. Run the app
```bash
python main.py
```

---

## File Structure

```
task_manager/
├── main.py          # UI layer — PyQt6 windows, cards, dialogs
├── backend.py       # Logic layer — CRUD, notifications, calendar
├── requirements.txt # pip dependencies
└── README.md        # This file
```

Tasks are saved automatically to `~/.taskmanager_tasks.json`
(your home directory), so they persist between sessions.

---

## Features

| Feature | Details |
|---|---|
| Task cards | Title, description, due date, estimated hours |
| Add / Edit / Delete | Full CRUD via modal dialog |
| Urgency colors | Card border changes: green → teal → amber → red based on due date |
| Search | Live filter across title and description |
| Sort | Newest / Due Soon / Hours / A–Z |
| Nav sidebar | All Tasks · Due Soon · Completed · Calendar views |
| Notifications | Background daemon checks every 60 s; alerts 30 min before deadline |
| Google Calendar | One-click sync (requires setup below) |

---

## Google Calendar Integration (Optional)

### Step 1 — Enable the API
1. Go to https://console.cloud.google.com
2. Create a project → **Enable the Google Calendar API**
3. Create **OAuth 2.0 credentials** → Desktop App
4. Download `credentials.json` and place it in the `task_manager/` folder

### Step 2 — Install extra libraries
```bash
pip install google-auth google-auth-oauthlib google-api-python-client
```

### Step 3 — Use it
Click the 📅 icon on any task card.  A browser window will open the first
time to authorize your Google account.  After that a token is cached at
`~/.taskmanager_gcal_token.json`.

---

## Notifications

Notifications require **plyer** (already in requirements.txt).

- On **Windows** — toast notifications via the system tray
- On **macOS** — system banner notifications
- On **Linux** — `notify-send` (install `libnotify-bin` if missing)

The background daemon wakes every **60 seconds** and fires a notification
for any task due within the next **30 minutes** (fires once per task).

---

## Troubleshooting

| Problem | Fix |
|---|---|
| `ModuleNotFoundError: PyQt6` | Run `pip install PyQt6` |
| Notifications not appearing | Run `pip install plyer`; on Linux install `libnotify-bin` |
| Google Calendar: `credentials.json not found` | Follow the Google Calendar setup above |
| App won't start on older Python | Upgrade to Python 3.10+ |
