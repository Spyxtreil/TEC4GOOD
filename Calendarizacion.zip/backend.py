"""
backend.py - Task Manager Core Logic
Handles task storage, CRUD operations, notifications, and calendar integration.
"""

import json
import os
import threading
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional


# ─── Data Storage ────────────────────────────────────────────────────────────

DATA_FILE = Path.home() / ".taskmanager_tasks.json"


def load_tasks() -> list[dict]:
    """Load tasks from local JSON file."""
    if DATA_FILE.exists():
        try:
            with open(DATA_FILE, "r") as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            return []
    return []


def save_tasks(tasks: list[dict]) -> None:
    """Persist tasks to local JSON file."""
    with open(DATA_FILE, "w") as f:
        json.dump(tasks, f, indent=2, default=str)


def add_task(tasks: list[dict], title: str, description: str,
             due_date: str, hours: float) -> dict:
    """Create and append a new task. Returns the new task dict."""
    task = {
        "id": int(time.time() * 1000),          # millisecond timestamp as ID
        "title": title.strip(),
        "description": description.strip(),
        "due_date": due_date,                    # ISO string "YYYY-MM-DD HH:MM"
        "hours": hours,
        "created_at": datetime.now().isoformat(),
        "completed": False,
    }
    tasks.append(task)
    save_tasks(tasks)
    return task


def update_task(tasks: list[dict], task_id: int, **kwargs) -> Optional[dict]:
    """Update fields of an existing task by ID."""
    for task in tasks:
        if task["id"] == task_id:
            for key, value in kwargs.items():
                if key in task:
                    task[key] = value
            save_tasks(tasks)
            return task
    return None


def delete_task(tasks: list[dict], task_id: int) -> bool:
    """Remove a task by ID. Returns True if found and removed."""
    original_len = len(tasks)
    tasks[:] = [t for t in tasks if t["id"] != task_id]
    if len(tasks) < original_len:
        save_tasks(tasks)
        return True
    return False


def get_task_by_id(tasks: list[dict], task_id: int) -> Optional[dict]:
    return next((t for t in tasks if t["id"] == task_id), None)


# ─── Notifications ───────────────────────────────────────────────────────────

def _try_notify(title: str, message: str) -> bool:
    """
    Attempt desktop notification via plyer, then fallback to tkinter messagebox.
    Returns True if plyer notification succeeded.
    """
    try:
        from plyer import notification
        notification.notify(
            title=title,
            message=message,
            app_name="Task Manager",
            timeout=8,
        )
        return True
    except Exception:
        return False


class NotificationDaemon:
    """
    Background thread that wakes every 60 seconds and fires reminders
    for tasks due within the next 30 minutes.
    """

    def __init__(self, task_getter, notified_ids: set):
        self._task_getter = task_getter      # callable returning current task list
        self._notified_ids = notified_ids    # shared set to avoid double-firing
        self._running = False
        self._thread: Optional[threading.Thread] = None

    def start(self):
        self._running = True
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def stop(self):
        self._running = False

    def _loop(self):
        while self._running:
            self._check()
            time.sleep(60)

    def _check(self):
        now = datetime.now()
        for task in self._task_getter():
            if task.get("completed"):
                continue
            try:
                due = datetime.fromisoformat(task["due_date"])
            except (ValueError, KeyError):
                continue
            delta = (due - now).total_seconds()
            key = (task["id"], "30m")
            if 0 < delta <= 1800 and key not in self._notified_ids:
                self._notified_ids.add(key)
                mins = int(delta / 60)
                _try_notify(
                    f"⏰ Due soon: {task['title']}",
                    f"Task due in ~{mins} minute{'s' if mins != 1 else ''}.",
                )


# ─── Google Calendar Integration (optional) ──────────────────────────────────

def add_to_google_calendar(task: dict) -> str:
    """
    Add a task to Google Calendar as an event.
    Returns a status message string.

    Prerequisites (not installed by default):
        pip install google-auth google-auth-oauthlib google-auth-httplib2 google-api-python-client
    A credentials.json OAuth file must be present in the working directory.
    """
    try:
        import os.path
        from google.auth.transport.requests import Request
        from google.oauth2.credentials import Credentials
        from google_auth_oauthlib.flow import InstalledAppFlow
        from googleapiclient.discovery import build

        SCOPES = ["https://www.googleapis.com/auth/calendar"]
        TOKEN_FILE = Path.home() / ".taskmanager_gcal_token.json"
        CREDS_FILE = Path("credentials.json")

        creds = None
        if TOKEN_FILE.exists():
            creds = Credentials.from_authorized_user_file(str(TOKEN_FILE), SCOPES)
        if not creds or not creds.valid:
            if creds and creds.expired and creds.refresh_token:
                creds.refresh(Request())
            else:
                if not CREDS_FILE.exists():
                    return "❌ credentials.json not found. See README for Google Calendar setup."
                flow = InstalledAppFlow.from_client_secrets_file(str(CREDS_FILE), SCOPES)
                creds = flow.run_local_server(port=0)
            with open(TOKEN_FILE, "w") as token:
                token.write(creds.to_json())

        service = build("calendar", "v3", credentials=creds)

        due = datetime.fromisoformat(task["due_date"])
        end = due + timedelta(hours=task.get("hours", 1))

        event = {
            "summary": task["title"],
            "description": task.get("description", ""),
            "start": {"dateTime": due.isoformat(), "timeZone": "UTC"},
            "end":   {"dateTime": end.isoformat(),   "timeZone": "UTC"},
        }
        created = service.events().insert(calendarId="primary", body=event).execute()
        return f"✅ Added to Google Calendar: {created.get('htmlLink')}"

    except ImportError:
        return "⚠️ Google API libraries not installed. Run:\npip install google-auth google-auth-oauthlib google-api-python-client"
    except Exception as e:
        return f"❌ Google Calendar error: {e}"
