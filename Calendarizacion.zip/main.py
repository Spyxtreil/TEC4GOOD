"""
main.py - Task Manager UI (PyQt6)
Clean, modern dark-themed desktop app for managing tasks with cards, modals,
notifications, and optional Google Calendar sync.
"""

import sys
from datetime import datetime
from typing import Optional

from PyQt6.QtCore import (Qt, QTimer, QPropertyAnimation, QEasingCurve,
                           QSize, pyqtSignal, QThread, QObject)
from PyQt6.QtGui import (QColor, QFont, QPalette, QIcon, QCursor,
                          QPainter, QPainterPath, QBrush, QPen, QPixmap,
                          QLinearGradient, QFontDatabase)
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QLineEdit, QTextEdit, QScrollArea, QFrame,
    QDialog, QDateTimeEdit, QDoubleSpinBox, QMessageBox, QGridLayout,
    QSizePolicy, QGraphicsDropShadowEffect, QSpacerItem, QStackedWidget,
    QTabWidget, QComboBox, QCheckBox, QSystemTrayIcon, QMenu
)

import backend


# ─── Color Palette ───────────────────────────────────────────────────────────

class Colors:
    BG          = "#0F0F13"       # deep near-black
    SURFACE     = "#17171F"       # card background
    SURFACE2    = "#1E1E2A"       # elevated surface
    BORDER      = "#2A2A3A"       # subtle border
    ACCENT      = "#7C6AF7"       # violet primary
    ACCENT2     = "#5EE8C0"       # teal secondary
    DANGER      = "#F76A6A"       # red for delete
    TEXT        = "#F0EFF8"       # primary text
    MUTED       = "#7A7A9A"       # secondary text
    WARN        = "#F7C56A"       # amber warning
    SUCCESS     = "#5EE8A0"       # green success


# ─── Stylesheet ──────────────────────────────────────────────────────────────

APP_STYLE = f"""
QMainWindow, QDialog {{
    background-color: {Colors.BG};
}}
QWidget {{
    background-color: transparent;
    color: {Colors.TEXT};
    font-family: 'Segoe UI', 'SF Pro Display', 'Helvetica Neue', Arial, sans-serif;
    font-size: 13px;
}}
QScrollArea {{
    border: none;
    background-color: transparent;
}}
QScrollBar:vertical {{
    background: {Colors.SURFACE};
    width: 6px;
    border-radius: 3px;
}}
QScrollBar::handle:vertical {{
    background: {Colors.BORDER};
    border-radius: 3px;
    min-height: 24px;
}}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0; }}
QScrollBar:horizontal {{ height: 6px; background: {Colors.SURFACE}; border-radius: 3px; }}
QScrollBar::handle:horizontal {{ background: {Colors.BORDER}; border-radius: 3px; }}
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {{ width: 0; }}
QLineEdit, QTextEdit, QDoubleSpinBox, QDateTimeEdit {{
    background-color: {Colors.SURFACE2};
    border: 1.5px solid {Colors.BORDER};
    border-radius: 8px;
    padding: 10px 14px;
    color: {Colors.TEXT};
    font-size: 13px;
    selection-background-color: {Colors.ACCENT};
}}
QLineEdit:focus, QTextEdit:focus, QDoubleSpinBox:focus, QDateTimeEdit:focus {{
    border-color: {Colors.ACCENT};
}}
QDoubleSpinBox::up-button, QDoubleSpinBox::down-button {{
    background: {Colors.BORDER};
    border: none;
    width: 18px;
}}
QDateTimeEdit::drop-down {{ border: none; width: 20px; }}
QComboBox {{
    background-color: {Colors.SURFACE2};
    border: 1.5px solid {Colors.BORDER};
    border-radius: 8px;
    padding: 8px 12px;
    color: {Colors.TEXT};
}}
QComboBox::drop-down {{ border: none; }}
QComboBox QAbstractItemView {{
    background: {Colors.SURFACE2};
    border: 1px solid {Colors.BORDER};
    selection-background-color: {Colors.ACCENT};
}}
QMessageBox {{
    background-color: {Colors.SURFACE};
}}
QMessageBox QPushButton {{
    background-color: {Colors.ACCENT};
    color: white;
    border: none;
    border-radius: 6px;
    padding: 6px 18px;
    min-width: 80px;
}}
"""


# ─── Helpers ─────────────────────────────────────────────────────────────────

def shadow(widget: QWidget, blur=20, x=0, y=4, color="#00000066"):
    eff = QGraphicsDropShadowEffect(widget)
    eff.setBlurRadius(blur)
    eff.setOffset(x, y)
    eff.setColor(QColor(color))
    widget.setGraphicsEffect(eff)
    return eff


def pill_button(text: str, color: str = Colors.ACCENT,
                text_color: str = "white", parent=None) -> QPushButton:
    btn = QPushButton(text, parent)
    btn.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
    btn.setStyleSheet(f"""
        QPushButton {{
            background-color: {color};
            color: {text_color};
            border: none;
            border-radius: 8px;
            padding: 9px 20px;
            font-weight: 600;
            font-size: 13px;
        }}
        QPushButton:hover {{
            background-color: {color}CC;
        }}
        QPushButton:pressed {{
            background-color: {color}99;
        }}
    """)
    return btn


def label(text: str, size=13, bold=False, color=Colors.TEXT,
          parent=None) -> QLabel:
    lbl = QLabel(text, parent)
    font = QFont()
    font.setPointSize(size)
    font.setBold(bold)
    lbl.setFont(font)
    lbl.setStyleSheet(f"color: {color};")
    return lbl


def format_date(iso: str) -> str:
    try:
        dt = datetime.fromisoformat(iso)
        return dt.strftime("%b %d, %Y  %H:%M")
    except Exception:
        return iso


def days_until(iso: str) -> Optional[int]:
    try:
        due = datetime.fromisoformat(iso)
        delta = (due - datetime.now()).total_seconds()
        return int(delta / 86400)
    except Exception:
        return None


# ─── Task Card ───────────────────────────────────────────────────────────────

class TaskCard(QFrame):
    """
    Compact, visually rich card representing a single task.
    Emits edit/delete signals so the main window handles logic.
    """
    edit_requested   = pyqtSignal(dict)
    delete_requested = pyqtSignal(dict)
    gcal_requested   = pyqtSignal(dict)

    def __init__(self, task: dict, parent=None):
        super().__init__(parent)
        self.task = task
        self._build()

    def _build(self):
        self.setFixedHeight(168)
        self.setMinimumWidth(300)

        days = days_until(self.task.get("due_date", ""))
        if days is None:
            urgency_color = Colors.MUTED
        elif days < 0:
            urgency_color = Colors.DANGER      # overdue
        elif days == 0:
            urgency_color = Colors.WARN        # today
        elif days <= 2:
            urgency_color = Colors.ACCENT2     # soon
        else:
            urgency_color = Colors.SUCCESS     # plenty of time

        self.setStyleSheet(f"""
            TaskCard {{
                background-color: {Colors.SURFACE};
                border-radius: 14px;
                border: 1.5px solid {Colors.BORDER};
                border-left: 4px solid {urgency_color};
            }}
            TaskCard:hover {{
                border-color: {Colors.ACCENT};
                border-left: 4px solid {urgency_color};
                background-color: {Colors.SURFACE2};
            }}
        """)
        shadow(self, blur=18, y=6, color="#00000055")

        root = QVBoxLayout(self)
        root.setContentsMargins(18, 14, 18, 14)
        root.setSpacing(6)

        # ── Row 1: title + action buttons ──
        top = QHBoxLayout()
        top.setSpacing(8)

        title_text = self.task.get("title", "Untitled")
        if len(title_text) > 32:
            title_text = title_text[:30] + "…"
        title_lbl = label(title_text, size=13, bold=True)
        title_lbl.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        top.addWidget(title_lbl)

        # Google Calendar sync button
        gcal_btn = QPushButton("📅")
        gcal_btn.setToolTip("Sync to Google Calendar")
        gcal_btn.setFixedSize(28, 28)
        gcal_btn.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        gcal_btn.setStyleSheet(f"""
            QPushButton {{ background: {Colors.SURFACE2}; border: 1px solid {Colors.BORDER};
                           border-radius: 6px; font-size: 13px; }}
            QPushButton:hover {{ background: {Colors.BORDER}; }}
        """)
        gcal_btn.clicked.connect(lambda: self.gcal_requested.emit(self.task))

        edit_btn = QPushButton("✏️")
        edit_btn.setToolTip("Edit task")
        edit_btn.setFixedSize(28, 28)
        edit_btn.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        edit_btn.setStyleSheet(f"""
            QPushButton {{ background: {Colors.SURFACE2}; border: 1px solid {Colors.BORDER};
                           border-radius: 6px; font-size: 13px; }}
            QPushButton:hover {{ background: {Colors.BORDER}; }}
        """)
        edit_btn.clicked.connect(lambda: self.edit_requested.emit(self.task))

        del_btn = QPushButton("🗑")
        del_btn.setToolTip("Delete task")
        del_btn.setFixedSize(28, 28)
        del_btn.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        del_btn.setStyleSheet(f"""
            QPushButton {{ background: {Colors.SURFACE2}; border: 1px solid {Colors.BORDER};
                           border-radius: 6px; font-size: 13px; }}
            QPushButton:hover {{ background: {Colors.DANGER}33; border-color: {Colors.DANGER}; }}
        """)
        del_btn.clicked.connect(lambda: self.delete_requested.emit(self.task))

        top.addWidget(gcal_btn)
        top.addWidget(edit_btn)
        top.addWidget(del_btn)
        root.addLayout(top)

        # ── Row 2: description ──
        desc_text = self.task.get("description", "No description.")
        if len(desc_text) > 90:
            desc_text = desc_text[:88] + "…"
        desc = label(desc_text, size=11, color=Colors.MUTED)
        desc.setWordWrap(True)
        root.addWidget(desc)

        root.addStretch()

        # ── Row 3: metadata pills ──
        meta = QHBoxLayout()
        meta.setSpacing(8)

        # Due date pill
        due_str = format_date(self.task.get("due_date", ""))
        due_text = f"📅  {due_str}" if due_str else "📅  No date"
        due_lbl = self._pill(due_text, urgency_color)
        meta.addWidget(due_lbl)

        # Hours pill
        hrs = self.task.get("hours", 0)
        hrs_lbl = self._pill(f"⏱  {hrs:.1f}h", Colors.MUTED)
        meta.addWidget(hrs_lbl)

        meta.addStretch()
        root.addLayout(meta)

    def _pill(self, text: str, color: str) -> QLabel:
        lbl = QLabel(text)
        lbl.setStyleSheet(f"""
            QLabel {{
                background-color: {color}22;
                color: {color};
                border: 1px solid {color}44;
                border-radius: 5px;
                padding: 2px 8px;
                font-size: 11px;
                font-weight: 600;
            }}
        """)
        return lbl


# ─── Task Form Dialog ─────────────────────────────────────────────────────────

class TaskDialog(QDialog):
    """Modal dialog for creating or editing a task."""

    def __init__(self, parent=None, task: dict = None):
        super().__init__(parent)
        self.task = task
        self.result_task = None
        self._build()

    def _build(self):
        self.setWindowTitle("Add Task" if not self.task else "Edit Task")
        self.setFixedWidth(480)
        self.setModal(True)
        self.setStyleSheet(f"""
            QDialog {{
                background-color: {Colors.SURFACE};
                border-radius: 16px;
            }}
        """)

        root = QVBoxLayout(self)
        root.setContentsMargins(32, 28, 32, 28)
        root.setSpacing(16)

        # Header
        mode = "New Task" if not self.task else "Edit Task"
        root.addWidget(label(mode, size=17, bold=True))
        root.addWidget(label("Fill in the details below.", size=11, color=Colors.MUTED))

        sep = QFrame()
        sep.setFrameShape(QFrame.Shape.HLine)
        sep.setStyleSheet(f"background: {Colors.BORDER}; max-height: 1px;")
        root.addWidget(sep)

        # Title
        root.addWidget(label("Title", size=11, bold=True, color=Colors.MUTED))
        self.title_input = QLineEdit()
        self.title_input.setPlaceholderText("e.g. Design review meeting")
        self.title_input.setMinimumHeight(40)
        root.addWidget(self.title_input)

        # Description
        root.addWidget(label("Description", size=11, bold=True, color=Colors.MUTED))
        self.desc_input = QTextEdit()
        self.desc_input.setPlaceholderText("Short description of what needs to be done…")
        self.desc_input.setFixedHeight(80)
        root.addWidget(self.desc_input)

        # Due date + hours (side by side)
        row = QHBoxLayout()
        row.setSpacing(16)

        left = QVBoxLayout()
        left.addWidget(label("Due Date & Time", size=11, bold=True, color=Colors.MUTED))
        self.date_input = QDateTimeEdit()
        self.date_input.setDisplayFormat("yyyy-MM-dd HH:mm")
        self.date_input.setCalendarPopup(True)
        self.date_input.setDateTime(
            self.date_input.dateTime().currentDateTime().addDays(1)
        )
        self.date_input.setMinimumHeight(40)
        left.addWidget(self.date_input)
        row.addLayout(left)

        right = QVBoxLayout()
        right.addWidget(label("Est. Hours", size=11, bold=True, color=Colors.MUTED))
        self.hours_input = QDoubleSpinBox()
        self.hours_input.setRange(0.5, 999)
        self.hours_input.setSingleStep(0.5)
        self.hours_input.setValue(1.0)
        self.hours_input.setSuffix("  hrs")
        self.hours_input.setMinimumHeight(40)
        right.addWidget(self.hours_input)
        row.addLayout(right)

        root.addLayout(row)
        root.addSpacing(8)

        # Buttons
        btn_row = QHBoxLayout()
        btn_row.setSpacing(12)

        cancel = pill_button("Cancel", color=Colors.SURFACE2, text_color=Colors.TEXT)
        cancel.setStyleSheet(cancel.styleSheet() + f"""
            QPushButton {{ border: 1.5px solid {Colors.BORDER}; }}
            QPushButton:hover {{ background-color: {Colors.BORDER}; }}
        """)
        cancel.clicked.connect(self.reject)
        btn_row.addWidget(cancel)

        save = pill_button("Save Task", color=Colors.ACCENT)
        save.clicked.connect(self._save)
        btn_row.addWidget(save)
        root.addLayout(btn_row)

        # Pre-fill if editing
        if self.task:
            self.title_input.setText(self.task.get("title", ""))
            self.desc_input.setPlainText(self.task.get("description", ""))
            self.hours_input.setValue(self.task.get("hours", 1.0))
            try:
                from PyQt6.QtCore import QDateTime
                dt = QDateTime.fromString(
                    self.task.get("due_date", ""), "yyyy-MM-dd HH:mm"
                )
                if dt.isValid():
                    self.date_input.setDateTime(dt)
            except Exception:
                pass

    def _save(self):
        title = self.title_input.text().strip()
        if not title:
            QMessageBox.warning(self, "Missing Title", "Please enter a task title.")
            return
        self.result_task = {
            "title":       title,
            "description": self.desc_input.toPlainText().strip(),
            "due_date":    self.date_input.dateTime().toString("yyyy-MM-dd HH:mm"),
            "hours":       self.hours_input.value(),
        }
        self.accept()


# ─── Empty State ─────────────────────────────────────────────────────────────

class EmptyState(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QVBoxLayout(self)
        lay.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.setSpacing(12)

        icon = QLabel("📋")
        icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
        icon.setStyleSheet("font-size: 52px;")
        lay.addWidget(icon)

        lay.addWidget(label("No tasks yet", size=16, bold=True,
                             color=Colors.MUTED))
        lay.addWidget(label("Click  + Add Task  to get started.",
                             size=11, color=Colors.BORDER))


# ─── Main Window ─────────────────────────────────────────────────────────────

class MainWindow(QMainWindow):

    def __init__(self):
        super().__init__()
        # Shared mutable task list (backend handles persistence)
        self.tasks: list[dict] = backend.load_tasks()
        self._notified_ids: set = set()
        self._notification_daemon = backend.NotificationDaemon(
            lambda: self.tasks, self._notified_ids
        )
        self._notification_daemon.start()
        self._build_ui()
        self._refresh_cards()

    # ── UI Construction ───────────────────────────────────────────────────

    def _build_ui(self):
        self.setWindowTitle("Task Manager")
        self.setMinimumSize(900, 620)
        self.resize(1120, 700)

        # Root widget with dark background
        root_widget = QWidget()
        root_widget.setStyleSheet(f"background-color: {Colors.BG};")
        self.setCentralWidget(root_widget)

        outer = QHBoxLayout(root_widget)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        # ── Sidebar ──
        sidebar = self._build_sidebar()
        outer.addWidget(sidebar)

        # ── Main content area ──
        content = QVBoxLayout()
        content.setContentsMargins(32, 28, 32, 24)
        content.setSpacing(20)

        # Header row
        header = QHBoxLayout()
        self.page_title = label("All Tasks", size=20, bold=True)
        header.addWidget(self.page_title)
        header.addStretch()

        self.task_count_lbl = label("0 tasks", size=12, color=Colors.MUTED)
        header.addWidget(self.task_count_lbl)

        add_btn = pill_button("+ Add Task")
        add_btn.clicked.connect(self._on_add_task)
        shadow(add_btn, blur=16, y=4, color=Colors.ACCENT + "55")
        header.addWidget(add_btn)
        content.addLayout(header)

        # Search bar
        search_row = QHBoxLayout()
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("🔍  Search tasks…")
        self.search_input.setMinimumHeight(40)
        self.search_input.textChanged.connect(self._refresh_cards)
        search_row.addWidget(self.search_input)

        # Sort dropdown
        self.sort_combo = QComboBox()
        self.sort_combo.addItems(["Sort: Newest", "Sort: Due Soon", "Sort: Hours ↑", "Sort: A–Z"])
        self.sort_combo.setFixedWidth(160)
        self.sort_combo.setMinimumHeight(40)
        self.sort_combo.currentIndexChanged.connect(self._refresh_cards)
        search_row.addWidget(self.sort_combo)
        content.addLayout(search_row)

        # Cards scroll area
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)

        self.cards_container = QWidget()
        self.cards_container.setStyleSheet("background: transparent;")
        self.cards_layout = QGridLayout(self.cards_container)
        self.cards_layout.setSpacing(16)
        self.cards_layout.setContentsMargins(0, 0, 8, 0)

        scroll.setWidget(self.cards_container)
        content.addWidget(scroll)

        # Status bar
        self.status_lbl = label("", size=10, color=Colors.MUTED)
        content.addWidget(self.status_lbl)

        outer.addLayout(content, stretch=1)

    def _build_sidebar(self) -> QWidget:
        sidebar = QWidget()
        sidebar.setFixedWidth(220)
        sidebar.setStyleSheet(f"""
            QWidget {{
                background-color: {Colors.SURFACE};
                border-right: 1px solid {Colors.BORDER};
            }}
        """)

        lay = QVBoxLayout(sidebar)
        lay.setContentsMargins(20, 28, 20, 20)
        lay.setSpacing(4)

        # App logo / name
        logo_row = QHBoxLayout()
        logo_icon = QLabel("✦")
        logo_icon.setStyleSheet(f"color: {Colors.ACCENT}; font-size: 22px; background: transparent;")
        logo_row.addWidget(logo_icon)
        logo_row.addWidget(label("TaskFlow", size=14, bold=True))
        logo_row.addStretch()
        lay.addLayout(logo_row)
        lay.addSpacing(20)

        # Nav items (visual only — all views show the same task list)
        items = [
            ("📋", "All Tasks"),
            ("⏰", "Due Soon"),
            ("✅", "Completed"),
            ("📅", "Calendar"),
        ]
        self.nav_buttons = []
        for icon_str, name in items:
            btn = QPushButton(f"  {icon_str}  {name}")
            btn.setCheckable(True)
            btn.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
            btn.setMinimumHeight(40)
            btn.setStyleSheet(f"""
                QPushButton {{
                    background: transparent;
                    color: {Colors.MUTED};
                    border: none;
                    border-radius: 8px;
                    text-align: left;
                    padding: 0 12px;
                    font-size: 13px;
                }}
                QPushButton:hover {{
                    background: {Colors.SURFACE2};
                    color: {Colors.TEXT};
                }}
                QPushButton:checked {{
                    background: {Colors.ACCENT}22;
                    color: {Colors.ACCENT};
                    font-weight: 600;
                }}
            """)
            btn.clicked.connect(lambda checked, b=btn, t=name: self._on_nav(b, t))
            lay.addWidget(btn)
            self.nav_buttons.append(btn)

        self.nav_buttons[0].setChecked(True)
        lay.addStretch()

        # Version footer
        ver = label("v1.0  ·  TaskFlow", size=9, color=Colors.BORDER)
        ver.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(ver)

        return sidebar

    # ── Navigation ────────────────────────────────────────────────────────

    def _on_nav(self, clicked_btn: QPushButton, name: str):
        for b in self.nav_buttons:
            b.setChecked(False)
        clicked_btn.setChecked(True)
        self.page_title.setText(name)
        self._refresh_cards(filter_mode=name)

    # ── Card Grid ─────────────────────────────────────────────────────────

    def _refresh_cards(self, *args, filter_mode: str = "All Tasks"):
        # Clear grid
        while self.cards_layout.count():
            item = self.cards_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        query = self.search_input.text().strip().lower()
        tasks = [t for t in self.tasks
                 if query in t.get("title", "").lower()
                 or query in t.get("description", "").lower()]

        # Filter by nav mode
        now = datetime.now()
        if filter_mode == "Due Soon":
            tasks = [t for t in tasks if (days := days_until(t.get("due_date", ""))) is not None and 0 <= days <= 3]
        elif filter_mode == "Completed":
            tasks = [t for t in tasks if t.get("completed")]
        elif filter_mode == "Calendar":
            tasks = sorted(tasks, key=lambda t: t.get("due_date", ""))

        # Sort
        sort_idx = self.sort_combo.currentIndex()
        if sort_idx == 0:   # Newest
            tasks = sorted(tasks, key=lambda t: t.get("created_at", ""), reverse=True)
        elif sort_idx == 1: # Due Soon
            tasks = sorted(tasks, key=lambda t: t.get("due_date", "9999"))
        elif sort_idx == 2: # Hours ↑
            tasks = sorted(tasks, key=lambda t: t.get("hours", 0))
        elif sort_idx == 3: # A–Z
            tasks = sorted(tasks, key=lambda t: t.get("title", "").lower())

        self.task_count_lbl.setText(f"{len(tasks)} task{'s' if len(tasks) != 1 else ''}")

        if not tasks:
            empty = EmptyState()
            self.cards_layout.addWidget(empty, 0, 0, 1, 3)
            return

        COLS = 3
        for i, task in enumerate(tasks):
            card = TaskCard(task)
            card.edit_requested.connect(self._on_edit_task)
            card.delete_requested.connect(self._on_delete_task)
            card.gcal_requested.connect(self._on_gcal_sync)
            self.cards_layout.addWidget(card, i // COLS, i % COLS)

        # Push cards to top
        self.cards_layout.setRowStretch(len(tasks) // COLS + 1, 1)

    # ── CRUD Handlers ─────────────────────────────────────────────────────

    def _on_add_task(self):
        dlg = TaskDialog(self)
        if dlg.exec() == QDialog.DialogCode.Accepted and dlg.result_task:
            d = dlg.result_task
            backend.add_task(self.tasks, d["title"], d["description"],
                             d["due_date"], d["hours"])
            self._refresh_cards()
            self._set_status(f"✅ Task "{d['title']}" added.")

    def _on_edit_task(self, task: dict):
        dlg = TaskDialog(self, task=task)
        if dlg.exec() == QDialog.DialogCode.Accepted and dlg.result_task:
            d = dlg.result_task
            backend.update_task(self.tasks, task["id"],
                                title=d["title"],
                                description=d["description"],
                                due_date=d["due_date"],
                                hours=d["hours"])
            self._refresh_cards()
            self._set_status(f"✏️ Task "{d['title']}" updated.")

    def _on_delete_task(self, task: dict):
        reply = QMessageBox.question(
            self, "Delete Task",
            f"Delete "{task.get('title', 'this task')}"?\nThis cannot be undone.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if reply == QMessageBox.StandardButton.Yes:
            backend.delete_task(self.tasks, task["id"])
            self._refresh_cards()
            self._set_status(f"🗑  Task deleted.")

    def _on_gcal_sync(self, task: dict):
        self._set_status("📅 Syncing to Google Calendar…")
        # Run in thread to avoid blocking UI
        def _run():
            msg = backend.add_to_google_calendar(task)
            QTimer.singleShot(0, lambda: self._set_status(msg))

        t = threading.Thread(target=_run, daemon=True)
        t.start()

    # ── Utility ───────────────────────────────────────────────────────────

    def _set_status(self, msg: str):
        self.status_lbl.setText(msg)
        QTimer.singleShot(6000, lambda: self.status_lbl.setText(""))

    def closeEvent(self, event):
        self._notification_daemon.stop()
        super().closeEvent(event)


# ─── Entry Point ─────────────────────────────────────────────────────────────

def main():
    app = QApplication(sys.argv)
    app.setApplicationName("TaskFlow")
    app.setStyle("Fusion")
    app.setStyleSheet(APP_STYLE)

    window = MainWindow()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
